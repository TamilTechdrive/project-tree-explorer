<?php
/**
 * Unique ID generator for projects, builds, child projects, child builds.
 *
 * Strategy:
 *   - Per-entity prefix (project / build / cproject / cbuild)
 *   - Monotonic counter persisted in api/.id_counters.json
 *   - File-locked for concurrent safety
 *
 * Returned shape: integer ID for direct DB column use, plus a typed string
 * helper (e.g. "PRJ-000123") when you need a display code.
 */

declare(strict_types=1);

const ID_PREFIXES = [
    'project'        => 'PRJ',
    'build'          => 'BLD',
    'child_project'  => 'CPR',
    'child_build'    => 'CBL',
];

function next_id(string $entity): int {
    if (!isset(ID_PREFIXES[$entity])) {
        throw new InvalidArgumentException("Unknown entity '$entity'");
    }
    $path = __DIR__ . '/.id_counters.json';
    $fp = fopen($path, 'c+');
    if (!$fp) throw new RuntimeException('cannot open id store');
    flock($fp, LOCK_EX);
    $raw = stream_get_contents($fp);
    $counters = $raw ? json_decode($raw, true) : [];
    if (!is_array($counters)) $counters = [];
    $counters[$entity] = ($counters[$entity] ?? 100) + 1;
    $id = $counters[$entity];
    ftruncate($fp, 0); rewind($fp);
    fwrite($fp, json_encode($counters));
    fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    return $id;
}

function id_code(string $entity, int $id): string {
    return sprintf('%s-%06d', ID_PREFIXES[$entity], $id);
}
