<?php
/**
 * Project–Build Hierarchy API
 * --------------------------------------------------------------
 * GET /api/projects.php
 *   Top-level listing with pagination / search / sort / filters.
 *
 * GET /api/projects.php?project_id=101
 *   Returns child structure (builds) for a single parent project.
 *
 * GET /api/projects.php?build_id=205
 *   Returns child projects (and their child builds) for a parent build.
 *
 * GET /api/projects.php?project_id=101&build_id=205
 *   Scoped fetch — child projects under build 205 inside project 101.
 *
 * Query params:
 *   page, page_size, search, sort, dir,
 *   project_id, build_id, bug_type (IR|PR|CR|FR),
 *   from (YYYY-MM-DD), to (YYYY-MM-DD), min_pct
 *
 * Response shape (top-level):
 *   { page, page_size, total, total_pages, items: [...], facets: {...} }
 *
 * Response shape (drill-down):
 *   { children: [...] }
 *
 * SQL note: this file ships with a JSON dummy dataset. The query helpers
 * are organized so swapping to PDO + the schema in db/schema.sql is a
 * direct, one-function change (see fetch_dataset()).
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/id_generator.php';

// ---------- input validation ----------
function param(string $k, $default = '') {
    $v = $_GET[$k] ?? $default;
    if (!is_scalar($v)) return $default;
    return trim((string)$v);
}
function int_param(string $k, int $default = 0): int {
    $v = param($k, (string)$default);
    return ctype_digit($v) ? (int)$v : $default;
}

$page      = max(1, int_param('page', 1));
$pageSize  = max(1, min(200, int_param('page_size', 25)));
$search    = param('search');
$sortKey   = in_array(param('sort','name'), ['name','bug_count','bug_effort','task_count','task_effort','total_pct'], true)
             ? param('sort','name') : 'name';
$sortDir   = strtolower(param('dir','asc')) === 'desc' ? 'desc' : 'asc';
$projectId = int_param('project_id', 0);
$buildId   = int_param('build_id', 0);
$bugType   = in_array(strtoupper(param('bug_type')), ['IR','PR','CR','FR'], true) ? strtoupper(param('bug_type')) : '';
$from      = preg_match('/^\d{4}-\d{2}-\d{2}$/', param('from')) ? param('from') : '';
$to        = preg_match('/^\d{4}-\d{2}-\d{2}$/', param('to'))   ? param('to')   : '';
$minPct    = param('min_pct') === '' ? null : (int)param('min_pct');

// ---------- data ----------
function fetch_dataset(): array {
    // Swap this with PDO->fetchAll() against the schema in db/schema.sql.
    return json_decode(file_get_contents(__DIR__ . '/data.json'), true);
}

$data = fetch_dataset();

// ---------- drill-down endpoints ----------
if ($buildId > 0) {
    foreach ($data as $pp) {
        foreach ($pp['builds'] as $pb) {
            if ($pb['build_id'] === $buildId) {
                // Child projects inherit metrics from the parent build when
                // they have no independent measurements ("inherit" = true).
                echo json_encode(['children' => $pb['child_projects'] ?? []]);
                exit;
            }
        }
    }
    echo json_encode(['children' => []]); exit;
}

if ($projectId > 0 && $buildId === 0 && !isset($_GET['page'])) {
    foreach ($data as $pp) {
        if ($pp['project_id'] === $projectId) {
            echo json_encode(['children' => $pp['builds'] ?? []]);
            exit;
        }
    }
    echo json_encode(['children' => []]); exit;
}

// ---------- top-level listing ----------
$items = $data;

// search
if ($search !== '') {
    $needle = mb_strtolower($search);
    $items = array_values(array_filter($items, function($p) use ($needle) {
        if (mb_strpos(mb_strtolower($p['name']), $needle) !== false) return true;
        foreach ($p['builds'] ?? [] as $b) {
            if (mb_strpos(mb_strtolower($b['name']), $needle) !== false) return true;
        }
        return false;
    }));
}

// filters
if ($projectId > 0) {
    $items = array_values(array_filter($items, fn($p) => $p['project_id'] === $projectId));
}
if ($buildId > 0) { /* handled above */ }
if ($bugType !== '') {
    foreach ($items as &$p) {
        $p['bug_count']  = $p['bugs_by_type'][$bugType] ?? 0;
        $p['bug_effort'] = $p['bug_effort_by_type'][$bugType] ?? 0;
    }
    unset($p);
}
if ($minPct !== null) {
    $items = array_values(array_filter($items, fn($p) => (int)($p['total_pct'] ?? 0) >= $minPct));
}
if ($from !== '' || $to !== '') {
    $items = array_values(array_filter($items, function($p) use ($from,$to) {
        $d = $p['updated_at'] ?? '';
        if ($from !== '' && $d < $from) return false;
        if ($to   !== '' && $d > $to)   return false;
        return true;
    }));
}

// sort
usort($items, function($a,$b) use ($sortKey,$sortDir) {
    $va = $a[$sortKey] ?? 0; $vb = $b[$sortKey] ?? 0;
    $cmp = is_numeric($va) && is_numeric($vb) ? ($va <=> $vb) : strcmp((string)$va, (string)$vb);
    return $sortDir === 'asc' ? $cmp : -$cmp;
});

// facets (for filter dropdowns)
$facets = [
    'projects' => array_map(fn($p) => ['project_id'=>$p['project_id'],'name'=>$p['name']], $data),
    'builds'   => [],
];
foreach ($data as $p) foreach ($p['builds'] ?? [] as $b) {
    $facets['builds'][] = ['build_id'=>$b['build_id'],'name'=>$b['name']];
}

// pagination
$total = count($items);
$totalPages = max(1, (int)ceil($total / $pageSize));
$page = min($page, $totalPages);
$slice = array_slice($items, ($page-1)*$pageSize, $pageSize);

// Strip nested children from top-level rows. Clients must request
// ?project_id=... to fetch the parent-build subtree (with cache).
$slice = array_map(function($p) {
    unset($p['builds']);
    return $p;
}, $slice);

echo json_encode([
    'page'        => $page,
    'page_size'   => $pageSize,
    'total'       => $total,
    'total_pages' => $totalPages,
    'items'       => $slice,
    'facets'      => $facets,
], JSON_UNESCAPED_SLASHES);
