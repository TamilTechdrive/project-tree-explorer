<?php
// Generates api/data.json using id_generator. Run once: php api/seed.php
require __DIR__.'/id_generator.php';
@unlink(__DIR__.'/.id_counters.json');
mt_srand(42);
function metric(){return['bug_count'=>mt_rand(0,40),'bug_effort'=>mt_rand(0,120),'task_count'=>mt_rand(2,60),'task_effort'=>mt_rand(10,300),'total_pct'=>mt_rand(0,100)];}
function bugs(){return['IR'=>mt_rand(0,20),'PR'=>mt_rand(0,15),'CR'=>mt_rand(0,10),'FR'=>mt_rand(0,8)];}
$out=[];
for($i=1;$i<=8;$i++){
  $pid=next_id('project');
  $p=array_merge(['project_id'=>$pid,'code'=>id_code('project',$pid),'name'=>"Parent Project $i",'updated_at'=>date('Y-m-d',strtotime("-".mt_rand(0,180)." days")),'bugs_by_type'=>bugs(),'bug_effort_by_type'=>bugs()],metric());
  $p['builds']=[];
  $nb=mt_rand(2,4);
  for($b=1;$b<=$nb;$b++){
    $bid=next_id('build');
    $pb=array_merge(['build_id'=>$bid,'project_id'=>$pid,'code'=>id_code('build',$bid),'name'=>"Parent Build $b"],metric());
    $pb['child_projects']=[];
    $ncp=mt_rand(1,3);
    for($c=1;$c<=$ncp;$c++){
      $cpid=next_id('child_project');
      $cp=array_merge(['child_project_id'=>$cpid,'build_id'=>$bid,'code'=>id_code('child_project',$cpid),'name'=>"Child Project $c",'inherit'=>true],metric());
      $cp['child_builds']=[];
      $ncb=mt_rand(1,3);
      for($d=1;$d<=$ncb;$d++){
        $cbid=next_id('child_build');
        $cp['child_builds'][]=array_merge(['child_build_id'=>$cbid,'child_project_id'=>$cpid,'code'=>id_code('child_build',$cbid),'name'=>"Child Build $d",'inherit'=>true],metric());
      }
      $pb['child_projects'][]=$cp;
    }
    $p['builds'][]=$pb;
  }
  $out[]=$p;
}
file_put_contents(__DIR__.'/data.json',json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
echo "ok: ".count($out)." projects\n";
