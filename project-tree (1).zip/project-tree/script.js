/* Project–Build Hierarchy Dashboard
 * Vanilla JS, event-delegated, with a parent-build cache so child rows
 * reuse already-loaded metrics instead of refetching.
 *
 * Lazy-load strategy
 * ------------------
 *  - Top-level GET returns only Parent Projects (no nested data).
 *  - Click a Parent Project  -> GET ?project_id=ID   returns full subtree
 *      (parent builds + child projects + child builds). Cached under pp:ID.
 *      Pre-seeds pb:* and cp:* caches so subsequent expands are instant.
 *  - Click a Parent Build / Child Project that was NOT pre-seeded
 *      (e.g. data came from a stale path) -> GET ?build_id=ID, cached.
 *  - All rows are collapsed on every (re)load.
 */
(() => {
  const API = "api/projects.php";

  const state = {
    page: 1,
    pageSize: 25,
    sort: { key: "name", dir: "asc" },
    search: "",
    filters: { project_id: "", build_id: "", bug_type: "", from: "", to: "", min_pct: "" },
    expanded: new Set(),    // pp:ID | pb:ID | cp:ID
    cache: new Map(),       // same keys -> children array
    loading: new Set(),     // in-flight keys (prevents double fetch)
    projects: [],
    totalPages: 1,
  };

  const $ = (s) => document.querySelector(s);
  const rowsEl = $("#rows");
  const spinner = $("#spinner");
  const errorEl = $("#error");
  const emptyEl = $("#empty");

  const fmt = (n) => (n == null ? "—" : Number(n).toLocaleString());
  const pctCell = (p) => {
    const v = Math.max(0, Math.min(100, Number(p) || 0));
    return `<span class="pct"><span class="bar"><span style="width:${v}%"></span></span>${v}%</span>`;
  };
  const badge = (type) => {
    const map = { pp:["pp","Parent Project"], pb:["pb","Parent Build"], cp:["cp","Child Project"], cb:["cb","Child Build"] };
    const [cls,label] = map[type]; return `<span class="badge ${cls}">${label}</span>`;
  };

  let spinnerCount = 0;
  const showSpinner = (on) => {
    spinnerCount = Math.max(0, spinnerCount + (on ? 1 : -1));
    spinner.hidden = spinnerCount === 0;
  };
  const showError = (msg) => { errorEl.textContent = msg; errorEl.hidden = !msg; };
  const showEmpty = (on) => emptyEl.hidden = !on;

  async function api(params = {}) {
    const qs = new URLSearchParams(params).toString();
    const res = await fetch(`${API}?${qs}`, { headers: { Accept: "application/json" } });
    if (!res.ok) throw new Error(`API ${res.status}`);
    return res.json();
  }

  async function loadProjects() {
    showSpinner(true); showError("");
    // Collapse everything on (re)load so the user sees a clean tree.
    state.expanded.clear();
    try {
      const data = await api({
        page: state.page, page_size: state.pageSize,
        search: state.search, sort: state.sort.key, dir: state.sort.dir,
        ...state.filters,
      });
      state.projects = data.items || [];
      state.totalPages = data.total_pages || 1;
      $("#pginfo").textContent = `Page ${data.page} / ${data.total_pages}`;
      hydrateFilterOptions(data.facets || {});
      render();
      showEmpty(state.projects.length === 0);
    } catch (e) {
      showError("Could not load projects. " + e.message);
    } finally { showSpinner(false); }
  }

  // Fetch full subtree for a parent project. Pre-seeds child caches.
  async function loadProjectSubtree(projectId) {
    const key = `pp:${projectId}`;
    if (state.cache.has(key)) return state.cache.get(key);
    const data = await api({ project_id: projectId });
    const builds = data.children || [];
    state.cache.set(key, builds);
    // Pre-seed pb:* and cp:* caches so further expands need no network.
    for (const pb of builds) {
      const cps = pb.child_projects || [];
      state.cache.set(`pb:${pb.build_id}`, cps);
      for (const cp of cps) {
        state.cache.set(`cp:${cp.child_project_id}`, cp.child_builds || []);
      }
    }
    return builds;
  }

  // Fetch a parent build's child projects (fallback when not pre-seeded).
  async function loadBuildChildren(buildId) {
    const key = `pb:${buildId}`;
    if (state.cache.has(key)) return state.cache.get(key);
    const data = await api({ build_id: buildId });
    const cps = data.children || [];
    state.cache.set(key, cps);
    for (const cp of cps) {
      state.cache.set(`cp:${cp.child_project_id}`, cp.child_builds || []);
    }
    return cps;
  }

  function render() {
    rowsEl.innerHTML = "";
    for (const pp of state.projects) {
      rowsEl.appendChild(rowEl(pp, 0, "pp"));
      if (state.expanded.has(`pp:${pp.project_id}`)) {
        const builds = state.cache.get(`pp:${pp.project_id}`) || [];
        for (const pb of builds) renderBuild(pb, 1);
      }
    }
  }

  function renderBuild(pb, level) {
    rowsEl.appendChild(rowEl(pb, level, "pb"));
    if (!state.expanded.has(`pb:${pb.build_id}`)) return;
    const kids = state.cache.get(`pb:${pb.build_id}`) || pb.child_projects || [];
    for (const cp of kids) {
      rowsEl.appendChild(rowEl(cp, level + 1, "cp", pb));
      if (state.expanded.has(`cp:${cp.child_project_id}`)) {
        const cbs = state.cache.get(`cp:${cp.child_project_id}`) || cp.child_builds || [];
        for (const cb of cbs) {
          rowsEl.appendChild(rowEl(cb, level + 2, "cb", pb));
        }
      }
    }
  }

  function rowEl(item, level, type, inheritFrom) {
    const tr = document.createElement("tr");
    tr.className = `lvl-${level} row-anim`;
    const id = type === "pp" ? item.project_id
      : type === "pb" ? item.build_id
      : type === "cp" ? item.child_project_id
      : item.child_build_id;
    tr.dataset.key = `${type}:${id}`;

    // Parents always show a toggle (children may need a fetch).
    const hasKids =
      type === "pp" ? true
      : type === "pb" ? true
      : type === "cp" ? (item.child_builds ? item.child_builds.length > 0 : true)
      : false;

    const isLoading = state.loading.has(tr.dataset.key);
    const open = state.expanded.has(tr.dataset.key);
    const toggle = `<span class="toggle ${hasKids ? "" : "leaf"} ${open ? "open" : ""} ${isLoading ? "loading" : ""}" data-action="toggle">${isLoading ? "⋯" : "›"}</span>`;
    const indent = `style="padding-left:${14 + level * 22}px"`;

    const src = (type === "cp" || type === "cb") && inheritFrom && item.inherit
      ? { ...inheritFrom, ...item }
      : item;

    tr.innerHTML = `
      <td ${indent}><span class="name-cell">${toggle}${badge(type)}<strong>${escapeHtml(item.name)}</strong></span></td>
      <td>${fmt(src.bug_count)}</td>
      <td>${fmt(src.bug_effort)}</td>
      <td>${fmt(src.task_count)}</td>
      <td>${fmt(src.task_effort)}</td>
      <td>${pctCell(src.total_pct)}</td>
    `;
    return tr;
  }

  function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}

  // Click-to-expand. Fetches lazily for pp/pb, uses cache for cp.
  rowsEl.addEventListener("click", async (e) => {
    const toggle = e.target.closest('[data-action="toggle"]');
    if (!toggle || toggle.classList.contains("leaf")) return;
    const tr = e.target.closest("tr");
    const key = tr.dataset.key;
    const [type, idStr] = key.split(":");
    const id = Number(idStr);

    // Collapse: simple state flip + re-render.
    if (state.expanded.has(key)) {
      state.expanded.delete(key);
      render();
      return;
    }

    // Expand: fetch if needed BEFORE flipping expanded, so the row only
    // shows "open" once data is actually present (no empty flicker).
    if (state.loading.has(key)) return;

    try {
      if (type === "pp" && !state.cache.has(key)) {
        state.loading.add(key); render(); showSpinner(true);
        await loadProjectSubtree(id);
      } else if (type === "pb" && !state.cache.has(key)) {
        state.loading.add(key); render(); showSpinner(true);
        await loadBuildChildren(id);
      }
      state.expanded.add(key);
    } catch (err) {
      showError(`Could not load children: ${err.message}`);
    } finally {
      if (state.loading.has(key)) { state.loading.delete(key); showSpinner(false); }
      render();
    }
  });

  // sorting / search / filters / pagination
  document.querySelectorAll("th[data-sort]").forEach(th => {
    th.addEventListener("click", () => {
      const k = th.dataset.sort;
      if (state.sort.key === k) state.sort.dir = state.sort.dir === "asc" ? "desc" : "asc";
      else { state.sort.key = k; state.sort.dir = "asc"; }
      state.page = 1; loadProjects();
    });
  });

  let searchT;
  $("#search").addEventListener("input", (e) => {
    clearTimeout(searchT);
    searchT = setTimeout(() => { state.search = e.target.value.trim(); state.page = 1; loadProjects(); }, 250);
  });

  $("#apply").addEventListener("click", () => {
    state.filters = {
      project_id: $("#f-project").value,
      build_id: $("#f-build").value,
      bug_type: $("#f-bug").value,
      from: $("#f-from").value,
      to: $("#f-to").value,
      min_pct: $("#f-pct").value,
    };
    state.page = 1; state.cache.clear(); loadProjects();
  });
  $("#reset").addEventListener("click", () => {
    ["f-project","f-build","f-bug","f-from","f-to","f-pct"].forEach(id => $("#"+id).value = "");
    state.filters = { project_id:"", build_id:"", bug_type:"", from:"", to:"", min_pct:"" };
    state.page = 1; state.cache.clear(); loadProjects();
  });

  $("#pgsize").addEventListener("change", (e) => { state.pageSize = Number(e.target.value); state.page = 1; loadProjects(); });
  $("#prev").addEventListener("click", () => { if (state.page > 1) { state.page--; loadProjects(); } });
  $("#next").addEventListener("click", () => { if (state.page < state.totalPages) { state.page++; loadProjects(); } });

  function hydrateFilterOptions(facets) {
    const pSel = $("#f-project"), bSel = $("#f-build");
    if (facets.projects && pSel.options.length <= 1) {
      facets.projects.forEach(p => pSel.add(new Option(p.name, p.project_id)));
    }
    if (facets.builds && bSel.options.length <= 1) {
      facets.builds.forEach(b => bSel.add(new Option(b.name, b.build_id)));
    }
  }

  loadProjects();
})();
