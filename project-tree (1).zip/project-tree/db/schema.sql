-- Project–Build hierarchy schema (MySQL/MariaDB compatible)
-- Parent-child mapping is enforced via FKs; bug categories are constrained
-- to IR / PR / CR / FR via an ENUM.

CREATE TABLE projects (
  project_id     INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name           VARCHAR(200) NOT NULL,
  created_at     DATE NOT NULL,
  updated_at     DATE NOT NULL
);

CREATE TABLE builds (
  build_id       INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  project_id     INT UNSIGNED NOT NULL,
  name           VARCHAR(200) NOT NULL,
  created_at     DATE NOT NULL,
  updated_at     DATE NOT NULL,
  FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE child_projects (
  child_project_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  build_id         INT UNSIGNED NOT NULL,
  name             VARCHAR(200) NOT NULL,
  -- when true, the row should display the parent build's metrics
  inherit_metrics  TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (build_id) REFERENCES builds(build_id) ON DELETE CASCADE
);

CREATE TABLE child_builds (
  child_build_id   INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  child_project_id INT UNSIGNED NOT NULL,
  name             VARCHAR(200) NOT NULL,
  FOREIGN KEY (child_project_id) REFERENCES child_projects(child_project_id) ON DELETE CASCADE
);

-- Per-row metrics. entity_type discriminates which ID column is set.
CREATE TABLE metrics (
  metric_id     BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  entity_type   ENUM('project','build','child_project','child_build') NOT NULL,
  entity_id     INT UNSIGNED NOT NULL,
  bug_count     INT UNSIGNED NOT NULL DEFAULT 0,
  bug_effort    INT UNSIGNED NOT NULL DEFAULT 0,
  task_count    INT UNSIGNED NOT NULL DEFAULT 0,
  task_effort   INT UNSIGNED NOT NULL DEFAULT 0,
  total_pct     TINYINT UNSIGNED NOT NULL DEFAULT 0,
  INDEX idx_entity (entity_type, entity_id)
);

CREATE TABLE bugs (
  bug_id        BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  entity_type   ENUM('project','build','child_project','child_build') NOT NULL,
  entity_id     INT UNSIGNED NOT NULL,
  bug_type      ENUM('IR','PR','CR','FR') NOT NULL,
  effort        INT UNSIGNED NOT NULL DEFAULT 0,
  reported_at   DATE NOT NULL,
  INDEX idx_entity (entity_type, entity_id),
  INDEX idx_type (bug_type)
);
