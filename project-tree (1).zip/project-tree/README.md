# Project–Build Hierarchy Dashboard

Standalone bundle: **HTML + CSS + Vanilla JS** frontend, **PHP** JSON API.

## Run locally

Requires PHP 8+.

```bash
cd project-tree
php -S localhost:8000
# open http://localhost:8000
```

The frontend (`index.html`, `style.css`, `script.js`) calls `api/projects.php`
which reads `api/data.json`. The dataset can be regenerated with:

```bash
php api/seed.php
```

## Project layout

```
project-tree/
├── index.html         # Tree-table UI
├── style.css          # Enterprise dashboard styling
├── script.js          # Modular vanilla JS (cache, events, render)
├── api/
│   ├── projects.php   # JSON REST endpoint
│   ├── id_generator.php # Unique ID generation (file-locked counter)
│   ├── seed.php       # Dummy data generator
│   └── data.json      # Sample dataset
└── db/
    └── schema.sql     # MySQL/MariaDB schema (projects, builds, child_*, metrics, bugs)
```

## API

| Endpoint | Purpose |
|---|---|
| `GET /api/projects.php?page=1&page_size=25` | Paginated top-level projects |
| `GET /api/projects.php?search=foo` | Search projects + builds |
| `GET /api/projects.php?sort=bug_count&dir=desc` | Sort |
| `GET /api/projects.php?project_id=101` | Drill down: builds for a project |
| `GET /api/projects.php?build_id=205` | Drill down: child projects for a build |
| `GET /api/projects.php?project_id=101&build_id=205` | Scoped drill down |
| `GET /api/projects.php?bug_type=IR&from=2025-01-01&to=2025-12-31&min_pct=50` | Filters |

### Top-level response

```json
{
  "page": 1, "page_size": 25, "total": 8, "total_pages": 1,
  "items": [
    {
      "project_id": 101, "code": "PRJ-000101", "name": "Parent Project 1",
      "bug_count": 12, "bug_effort": 40, "task_count": 30, "task_effort": 120, "total_pct": 64,
      "bugs_by_type": {"IR": 4, "PR": 3, "CR": 2, "FR": 3},
      "builds": [ { "build_id": 205, "name": "Parent Build 1", "child_projects": [ ... ] } ]
    }
  ],
  "facets": { "projects": [...], "builds": [...] }
}
```

## Unique IDs

`api/id_generator.php` exposes `next_id($entity)` and `id_code($entity,$id)`
for `project`, `build`, `child_project`, `child_build`. Counters are persisted
in `api/.id_counters.json` with `flock()` so concurrent requests are safe.

## Data optimization (frontend cache)

- Top-level fetch returns each parent project's builds with their child
  projects embedded. Expanding rows costs **0 API calls** until you reach
  data not yet loaded.
- A `Map` keyed by `pb:<build_id>` / `pp:<project_id>` caches every
  drill-down response. Re-expanding never refetches.
- Child rows with `inherit: true` reuse the parent build's `bug_count`,
  `bug_effort`, `task_count`, `task_effort`, `total_pct` for display —
  no duplicate aggregation in the API or DB.

## Switching to a real database

Replace `fetch_dataset()` in `api/projects.php` with a PDO query against
`db/schema.sql`. The rest of the file (filters, sort, pagination, facets)
operates on a plain PHP array — no rewrite needed.

## Bug categories

`IR`, `PR`, `CR`, `FR` are the only accepted values (validated server-side
and enforced via the `bugs.bug_type` ENUM in `db/schema.sql`).
